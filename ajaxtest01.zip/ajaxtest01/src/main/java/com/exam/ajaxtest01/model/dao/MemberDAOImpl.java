package com.exam.ajaxtest01.model.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.exam.ajaxtest01.model.dto.MemberVO;

@Repository 
public class MemberDAOImpl implements MemberDAO {
	
	@Inject
	SqlSession sqlSession;
	
	@Override
	public List<MemberVO> listAll() throws Exception {
		// TODO Auto-generated method stub
		Map<String,Object> map = new HashMap<String, Object>();
		System.out.println("MemberDAO listAll()");
		return sqlSession.selectList("member.listAll", map);
	}

}
