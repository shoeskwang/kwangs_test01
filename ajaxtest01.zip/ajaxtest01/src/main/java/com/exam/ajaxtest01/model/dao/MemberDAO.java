package com.exam.ajaxtest01.model.dao;

import java.util.List;

import com.exam.ajaxtest01.model.dto.MemberVO;

public interface MemberDAO {
	public List<MemberVO> listAll() throws Exception;
}
