package com.exam.ajaxtest01.service;

import java.util.List;

import com.exam.ajaxtest01.model.dto.MemberVO;

public interface MemberService {
	 public List<MemberVO> listAll() throws Exception;
}
