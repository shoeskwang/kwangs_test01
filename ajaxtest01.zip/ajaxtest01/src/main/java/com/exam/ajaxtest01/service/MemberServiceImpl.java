package com.exam.ajaxtest01.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.exam.ajaxtest01.model.dao.MemberDAO;
import com.exam.ajaxtest01.model.dto.MemberVO;

@Service
public class MemberServiceImpl implements MemberService {
	
	@Inject
	MemberDAO memberDao;

	@Override
	public List<MemberVO> listAll() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("MemberService listAll()");
		return memberDao.listAll();
	}

}
